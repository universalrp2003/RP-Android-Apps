Oor Arivippu 1.1.15 - owner-authorized redacted screenshot artwork

Four real uploaded screenshots. Names/towns are partially hidden using opaque pixel masks; report date/time hidden. Status/navigation bars and underlying dialog background cropped. Originals are not included. No generative edits, blur, private invitation or comparison code.

The screenshots show captured UI states, not a guarantee of current location, background operation, audible speech or security. No app-store submission or Store APK rebuild was performed. Retain the redactions when reusing these images.
